﻿using Amazon;
using Amazon.SecretsManager;
using Amazon.SecretsManager.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Prokeep.Operations;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Prokeep.Exercise
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                dynamic json = JsonConvert.DeserializeObject(AWS.Execute());

                Console.WriteLine(JsonConvert.SerializeObject(json, Formatting.Indented));

                Console.WriteLine("\r\nPress enter key to close the console window...");

                Console.Read();
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

                Console.WriteLine("\r\nPress enter key to close the console window...");

                Console.Read();
            }
        }

        
    }
}
