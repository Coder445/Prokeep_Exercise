﻿using Amazon;
using Amazon.SecretsManager;
using Amazon.SecretsManager.Model;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Prokeep.Operations
{
    public class AWS
    {
        public static string GetSecret(string arn, string key, string secret)
        {
            var config = new AmazonSecretsManagerConfig { RegionEndpoint = RegionEndpoint.USWest2 };

            IAmazonSecretsManager client = new AmazonSecretsManagerClient(key, secret, config);

            GetSecretValueRequest request = new GetSecretValueRequest()
            {
                SecretId = arn,
                VersionStage = "AWSCURRENT"
            };
            GetSecretValueResponse response = null;
            try
            {
                response = client.GetSecretValue(request);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            return response.SecretString;
        }

        public static string CallWebservice(string url, string user, string pw)
        {
            HttpClient client = new HttpClient();
            var byteArray = Encoding.ASCII.GetBytes(user+":"+pw);
            client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

            HttpResponseMessage response = client.GetAsync(url).Result;
           
           return response.Content.ReadAsStringAsync().Result;            
        }        

        public static string Execute()
        {
            string arn = ConfigurationManager.AppSettings["ARN"];
            string accessKey = System.Environment.GetEnvironmentVariable("AccessKey");
            string secretKey = System.Environment.GetEnvironmentVariable("SecretKey");
            string url = ConfigurationManager.AppSettings["URL"];

            string credentials = AWS.GetSecret(arn, accessKey, secretKey);

            JObject jsonObj = (JObject)JsonConvert.DeserializeObject(credentials);

            string user = (string)jsonObj["username"];
            string pw = (string)jsonObj["password"];

            return AWS.CallWebservice(url, user, pw);            
        }
    }
}
