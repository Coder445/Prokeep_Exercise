﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Prokeep.Operations;
using Newtonsoft.Json.Linq;

namespace Prokeep.UnitTest
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void AssertJSON()
        {
            bool isJson = false;
            JToken.Parse(AWS.Execute());
            isJson = true;
            Assert.IsTrue(isJson);
        }
    }
}
